#include <my_global.h>
#include <mysql.h>
#include <stdio.h>
#include <cstdlib>
#include <time.h>
#include "DB.h"

#define MAX_NODE 10

#ifdef DEBUG
#define printError(...) printf("the_error_is_in_%d\n",__VA_ARGS__)
#else
#define printError(...)  
#endif

MYSQL *con;

extern char* NWKSKEY[MAX_NODE];
extern char* APPSKEY[MAX_NODE];
extern int node_number;
void get_keys()
{
   con = mysql_init(NULL);
   if (con == NULL) 
    {
      fprintf(stderr, "%s\n", mysql_error(con));
      printError(1);
      exit(1);
    }

    if (mysql_real_connect(con, "studev.groept.be", "a16_mds_1", "3wd87myr", 
          "a16_mds_1", 3306, NULL, 0) == NULL) 
    {
       fprintf(stderr, "%s\n", mysql_error(con));
       mysql_close(con);
       printError(2);
       exit(1);
   }   
    if (mysql_query(con, "SELECT nwkskey, appskey FROM gps_node WHERE nwkskey IS NOT NULL AND appskey IS NOT NULL")) 
  {
      finish_with_error();
      printError(4);
  }
  
  MYSQL_RES *result = mysql_store_result(con);
  
  if (result == NULL) 
  {
      finish_with_error();
      printError(5);
  }

  int num_fields = mysql_num_fields(result);

  MYSQL_ROW row;
  
  printf("\n------------------------------------------------------------------------------------------\n");
  int number = 0;
  printf("NWKSKEY \t \t \t \t | \t "); 
  printf("APPSKEY \t \t \t \t | \t ");
  printf("\n------------------------------------------------------------------------------------------\n");
  while ((row = mysql_fetch_row(result))) 
  { 
      
      
      	  NWKSKEY[number] = row[0];
      	  APPSKEY[number] = row[1];
          printf("%s \t | \t ", NWKSKEY[number]); 
          printf("%s \t | \t ", APPSKEY[number]);
    	 
          printf("\n__________________________________________________________________________________________\n");
	  number++;
  }
 node_number = number-1;
  printf("------------------------------------------------------------------------------------------\n"); 
  
  mysql_free_result(result);
  mysql_close(con);
  printf("done ;)\n");
    
}



void finish_with_error(){
  fprintf(stderr, "%s\n", mysql_error(con));
  mysql_close(con);
  exit(1);        
}





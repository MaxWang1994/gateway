#include <stdio.h>

#include <curl/curl.h>
 

 
static size_t read_callback(void *ptr, size_t size, size_t nmemb, void *userp);
 
int sendToPhp(char *data);
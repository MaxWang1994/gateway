#ifndef __STR2HEX_H
#define __STR2HEX_H

#include <stdint.h>

int str2hex(const char *str, uint8_t *hex, int max_len);

#endif

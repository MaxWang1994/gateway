#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char frame[] = "QAMBAQKAWwABp5+scHk=";
// char hex[] = "40 03 01 01 02 80 5B 00 01 A7 9F AC 70 79";
char hex[] = "40 94 15 01 26 00 C3 00 01 28 1D 06 70 DD E1 21 EC DD F6 90 C2 EC 39 C4 8A";


int main()
{
    char command[400];
    strcpy(command, "lorawan-parser/util/parser/lwp --parse \"");

    strcat(command, hex);
    strcat(command, "\" --nwkskey ");
    strcat(command, newskey);
    strcat(command, " --appskey ");
    strcat(command, appskey);
    strcat(command, " --appkey ");
    strcat(command, appskey);
    strcat(command, " >some.txt");
    system(command);

    return 0;
}
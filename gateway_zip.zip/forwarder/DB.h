#define MAX_NODE 10


void get_keys();
void finish_with_error();


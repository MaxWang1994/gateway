#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char frame[] = "QAMBAQKAWwABp5+scHk=";
// char hex[] = "40 03 01 01 02 80 5B 00 01 A7 9F AC 70 79";
char hex[] = "40 94 15 01 26 00 C3 00 01 28 1D 06 70 DD E1 21 EC DD F6 90 C2 EC 39 C4 8A";
char appkey[] = "B827EBFFFF3B1365";
char appskey[] = "5B1180808E941FBB9AC92DAE69892805";
char newskey[] = "4864A8A925AE522802D3A3740BAA15CE";

int main()
{
    char command[400];
    strcpy(command, "../lorawan-parser/util/parser/lwp -c lwp-config.json \"");

    strcat(command, hex);
    strcat(command, "\" --nwkskey ");
    strcat(command, newskey);
    strcat(command, " --appskey ");
    strcat(command, appskey);
    strcat(command, " --appkey ");
    strcat(command, appskey);
	
    system(command);
    FILE *ls = popen("ls", "r");
    char buf[1000];
    while(fgets(buf,sizeof(buf),ls)!=0){
   	
	
    }

printf("data:");
 printf("%c", buf[0]);
 printf("%c", buf[1]);
 printf("%c", buf[2]);
 printf("%c", buf[3]);
	pclose(ls);
    return 0;
}
#ifndef __VERSIONING__
#define __VERSIONING__

#define VMAJOR          (0)
#define VMINOR          (2)
#define VPATCH          (0)

#endif // __VERSIONING__
